---
title: PS4 Custom-card
hide:
  - toc
---

<!-- markdownlint-disable MD046 -->

### Playstation

> NOTE
> This card is under review and is not ready to use!

<details>
<summary>Usage</summary>

#### Example

```yaml
- type: "custom:button-card"
  template: card_ps4
  entity: media_player.example
```

#### Variables

<table>
<tr>
<th>Variable</th>
<th>Example</th>
<th>Required</th>
<th>Explanation</th>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</table>
<br />
</details>

??? note "Template Code"

    ```yaml title="custom_card_playstation.yaml"
    --8<-- "custom_cards/custom_card_playstation/custom_card_playstation.yaml"
    ```
